//package com.paquage.web;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//
//import com.paquage.entities.AppUser;
//import com.paquage.services.AppServices;
//
//@Controller
//@CrossOrigin("*")
//public class AcountRestController {
//	@Autowired
//	private AppServices appServices;
//	
//	@PostMapping("/register")
//	public AppUser register(@RequestBody RegisterForm userForm) {
//		if (!userForm.getPassword().equals(userForm.getRepassword()))
//			throw new RuntimeException("Confirmez votre mot de passe");
//		AppUser user=appServices.findUserByEmail(userForm.getEmail());
//		if(user!=null) throw new RuntimeException("cet utilisateur existe deja");
//		AppUser appUser=new AppUser();
//		appUser.setEmail(userForm.getEmail());
//		appUser.setPassword(userForm.getPassword());
//		
//		appServices.saveUser(appUser);
//		appServices.addRoleToUse(userForm.getEmail(), "USER");
//		return appUser;
//	}
//}
