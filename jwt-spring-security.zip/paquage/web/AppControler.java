package com.paquage.web;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.paquage.dao.CandidatRepository;
import com.paquage.entities.AppUser;
import com.paquage.entities.Candidat;
import com.paquage.entities.Certification;
import com.paquage.entities.CertificationCandidat;
import com.paquage.entities.Domaine;
import com.paquage.entities.Experience;
import com.paquage.entities.Formation;
import com.paquage.entities.Reference;
import com.paquage.entities.Technologie;
import com.paquage.services.AppServices;

@RestController
@RequestMapping("/api_cvtheque")
@CrossOrigin("*")
public class AppControler {
	
	@Autowired
	private AppServices appServices;
	
	
//	// CANDIDAT
		
	@GetMapping(value = "/candidats")
	public List<Candidat> allCandidat(){
		return appServices.allCandidats();
	}
	
	@RequestMapping(value = "/candidats/{id}", method=RequestMethod.GET)
	public Candidat candidat(@PathVariable ("id")Long id){
		System.out.println("ffffffffffffff : "+id);
		return appServices.findCandidat(id);
	}
	
	@RequestMapping(value = "/candidats", method=RequestMethod.POST)
	public Candidat saveCandidat(@RequestBody Candidat candidat){
		System.out.println(candidat.getEmail());
		System.out.println(candidat.getPassword());
		System.out.println(candidat.getEtat());
		return appServices.saveCandidat(candidat);
	}
	@RequestMapping(value = "/candidats/{id}", method=RequestMethod.PUT)
	public Candidat updateCandidat(@RequestBody Candidat candidat, @PathVariable Long id){
		candidat.setId(id);
		return appServices.updateCandidat(candidat);
	}
	
	
	@RequestMapping(value = "/candidats/{id}", method=RequestMethod.DELETE)
	public boolean deleteCandidat(@PathVariable Long id){
		appServices.deleteCandidat(id);
		return true;
	}
	
	@RequestMapping(value = "/candidatByMotCle", method=RequestMethod.GET)
	public Page<Candidat> findCandidats(
			@RequestParam(name="motCle",defaultValue="") String motCle,
			@RequestParam(name="page",defaultValue="0") int  page,
			@RequestParam(name="size",defaultValue="24") int size){
		return appServices.findCandidats("%"+motCle+"%", page, size);
	}
		
//		// CERTIFICATION
		
	@GetMapping(value = "/certifications")
	public List<Certification> allCertification(){
		return appServices.allCertifications();
	}
	
	@GetMapping(value = "/certifications/{id}")
	public Certification certification(@PathVariable ("id")Long id){
		return appServices.findCertification(id);
	}
	
	@PostMapping(value = "/certifications")
	public Certification saveCertification(@RequestBody Certification certification){
		return appServices.saveCertification(certification);
	}
	@PutMapping(value = "/certifications/{id}")
	public Certification updateCertification(@RequestBody Certification certification, @PathVariable Long id){
		certification.setId(id);
		return appServices.updateCertification(certification);
	}
	
	
	@DeleteMapping(value = "/certifications/{id}")
	public boolean deleteCertification(@PathVariable Long id){
		appServices.deleteCertification(id);
		return true;
	}
	
	@GetMapping(value = "/certificationByMotCle")
	public Page<Certification> findCertifications(
			@RequestParam(name="motCle",defaultValue="") String motCle,
			@RequestParam(name="page",defaultValue="0") int  page,
			@RequestParam(name="size",defaultValue="24") int size){
		System.out.println(motCle);
		System.out.println(page);
		System.out.println(size);
		return appServices.findCertifications("%"+motCle+"%", page, size);
	}
		
		// DOMAINE DE COMPETENCE
		
		@GetMapping(value = "/domaines")
		public List<Domaine> allDomaine(){
			return appServices.allDomaines();
		}
		
		@GetMapping(value = "/domaines/{id}")
		public Domaine domaine(@PathVariable ("id")Long id){
			return appServices.findDomaine(id);
		}
		
		@PostMapping(value = "/domaines")
		public Domaine saveDomaine(@RequestBody Domaine domaine){
			return appServices.saveDomaine(domaine);
		}
		@PutMapping(value = "/domaines/{id}")
		public Domaine updateDomaine(@RequestBody Domaine domaine, @PathVariable Long id){
			domaine.setId(id);
			return appServices.updateDomaine(domaine);
		}
		
		
		@DeleteMapping(value = "/domaines/{id}")
		public boolean deleteDomaine(@PathVariable Long id){
			appServices.deleteDomaine(id);
			return true;
		}
		
		@GetMapping(value = "/domaineByMotCle")
		public Page<Domaine> findDomaines(
				@RequestParam(name="motCle",defaultValue="") String motCle,
				@RequestParam(name="page",defaultValue="0") int  page,
				@RequestParam(name="size",defaultValue="24") int size){
			return appServices.findDomaines("%"+motCle+"%", page, size);
		}
		
		
		// EXPERIENCE
		
		@GetMapping(value = "/experiences")
		public List<Experience> allExperience(){
			return appServices.allExperiences();
		}
		
		@GetMapping(value = "/experiences/{id}")
		public Experience experience(@PathVariable ("id")Long id){
			return appServices.findExperience(id);
		}
		
		@PostMapping(value = "/experiences")
		public Experience saveExperience(@RequestBody Experience experience){
			return appServices.saveExperience(experience);
		}
		@PutMapping(value = "/experiences/{id}")
		public Experience updateExperience(@RequestBody Experience experience, @PathVariable Long id){
			experience.setId(id);
			return appServices.updateExperience(experience);
		}
		
		
		@DeleteMapping(value = "/experiences/{id}")
		public boolean deleteExperience(@PathVariable Long id){
			appServices.deleteExperience(id);
			return true;
		}
		
		@GetMapping(value = "/experienceByMotCle")
		public Page<Experience> findExperiences(
				@RequestParam(name="motCle",defaultValue="") String motCle,
				@RequestParam(name="page",defaultValue="0") int  page,
				@RequestParam(name="size",defaultValue="24") int size){
			return appServices.findExperiences("%"+motCle+"%", page, size);
		}
		
		// FORMATIONS
		
		@GetMapping(value = "/formations")
	public List<Formation> allFormation(){
		return appServices.allFormations();
	}
	
	@GetMapping(value = "/formations/{id}")
	public Formation formation(@PathVariable ("id")Long id){
		return appServices.findFormation(id);
	}
	
	@PostMapping(value = "/formations")
	public Formation saveFormation(@RequestBody Formation formation){
		return appServices.saveFormation(formation);
	}
	@PutMapping(value = "/formations/{id}")
	public Formation updateFormation(@RequestBody Formation formation, @PathVariable Long id){
		formation.setId(id);
		return appServices.updateFormation(formation);
	}
	
	
	@DeleteMapping(value = "/formations/{id}")
	public boolean deleteFormation(@PathVariable Long id){
		appServices.deleteFormation(id);
		return true;
	}
	
	@GetMapping(value = "/formationByMotCle")
	public Page<Formation> findFormations(
			@RequestParam(name="motCle",defaultValue="") String motCle,
			@RequestParam(name="page",defaultValue="0") int  page,
			@RequestParam(name="size",defaultValue="24") int size){
		return appServices.findFormations("%"+motCle+"%", page, size);
	}
		
		

	/*
		// LOISIR
		
		@GetMapping(value = "/loisirs")
		public List<Loisirs> pageLoisirs(int page, int size){
			return appServices.allLoisirs(page, size);
		}
		
		@GetMapping(value = "/loisirs/{id}")
		public Loisirs getLoisir(@PathVariable ("id")Long id){
			
			return appServices.findLoisir(id);
		}
		
		@PostMapping(value = "/loisirs")
		public Loisirs saveLoisir(@RequestBody Loisirs loisir){
			return appServices.saveLoisir(loisir);
		}
		@PutMapping(value = "/loisirs/{id}")
		public Loisirs updateLoisirs(@RequestBody Loisirs loisir, @PathVariable Long id){
			loisir.setId(id);
			return appServices.updateLoisir(loisir);
		}
		
		@DeleteMapping(value = "/loisirs/{id}")
		public void deleteLoisirs(@PathVariable ("id")Long id){
			appServices.deleteLoisir(id);
		}
		@GetMapping(value = "/chercherLoisirs")
		public Page<Loisirs> findLoisirs(String motCle,
				@RequestParam(name="page",defaultValue="0") int  page,
				@RequestParam(name="size",defaultValue="4") int size){
			return appServices.findLoisirs("%"+motCle+"%", page, size);
		} */
		
		// REFERENCE EXPEREIENCE
		
		@GetMapping(value = "/references")
	public List<Reference> allReference(){
		return appServices.allReferences();
	}
	
	@GetMapping(value = "/references/{id}")
	public Reference reference(@PathVariable ("id")Long id){
		return appServices.findReference(id);
	}
	
	@PostMapping(value = "/references")
	public Reference saveReference(@RequestBody Reference reference){
		return appServices.saveReference(reference);
	}
	@PutMapping(value = "/references/{id}")
	public Reference updateReference(@RequestBody Reference reference, @PathVariable Long id){
		reference.setId(id);
		return appServices.updateReference(reference);
	}
	
	
	@DeleteMapping(value = "/references/{id}")
	public boolean deleteReference(@PathVariable Long id){
		appServices.deleteReference(id);
		return true;
	}
	
	@GetMapping(value = "/referenceByMotCle")
	public Page<Reference> findReferences(
			@RequestParam(name="motCle",defaultValue="") String motCle,
			@RequestParam(name="page",defaultValue="0") int  page,
			@RequestParam(name="size",defaultValue="24") int size){
		return appServices.findReferences("%"+motCle+"%", page, size);
	}
		
		// TECHNOLOGIE
		
		
	@GetMapping(value = "/technologies")
	public List<Technologie> allTechnologie(){
		return appServices.allTechnologies();
	}
	
	@GetMapping(value = "/technologies/{id}")
	public Technologie technologie(@PathVariable ("id")Long id){
		return appServices.findTechnologie(id);
	}
	
	@PostMapping(value = "/technologies")
	public Technologie saveTechnologie(@RequestBody Technologie technologie){
		return appServices.saveTechnologie(technologie);
	}
	@PutMapping(value = "/technologies/{id}")
	public Technologie updateTechnologie(@RequestBody Technologie technologie, @PathVariable Long id){
		technologie.setId(id);
		return appServices.updateTechnologie(technologie);
	}
	
	
	@DeleteMapping(value = "/technologies/{id}")
	public boolean deleteTechnologie(@PathVariable Long id){
		appServices.deleteTechnologie(id);
		return true;
	}
	
	@GetMapping(value = "/technologieByMotCle")
	public Page<Technologie> findTechnologies(
			@RequestParam(name="motCle",defaultValue="") String motCle,
			@RequestParam(name="page",defaultValue="0") int  page,
			@RequestParam(name="size",defaultValue="24") int size){
		return appServices.findTechnologies("%"+motCle+"%", page, size);
	}
		
		// CERTIFICATION CANDIDAT
	
		@GetMapping(value = "/certificationCandidats")
	public List<CertificationCandidat> allCertificationCandidat(){
		return appServices.allCertifCandidats();
	}
	
//	@GetMapping(value = "/certificationCandidats/{id}")
//	public CertificationCandidat certificationCandidat(@PathVariable ("id")Long id){
//		return appServices.findCertifCandidat(id);
//	}
	
	@PostMapping(value = "/certificationCandidats")
	public CertificationCandidat saveCertificationCandidat(@RequestBody CertificationCandidat certificationCandidat){
		return appServices.saveCertifCandidat(certificationCandidat);
	}
	@PutMapping(value = "/certificationCandidats/{id}")
	public CertificationCandidat updateCertificationCandidat(@RequestBody CertificationCandidat certificationCandidat, @PathVariable Long id){
		certificationCandidat.setId(id);
		return appServices.updateCertifCandidat(certificationCandidat);
	}
	
	
	@DeleteMapping(value = "/certificationCandidats/{id}")
	public boolean deleteCertificationCandidat(@PathVariable Long id){
		appServices.deleteCertifCandidat(id);
		return true;
	}
	
	@GetMapping(value = "/certificationCandidatByMotCle")
	public Page<Certification> findCertificationCandidats(
			@RequestParam(name="motCle",defaultValue="") String motCle,
			@RequestParam(name="page",defaultValue="0") int  page,
			@RequestParam(name="size",defaultValue="24") int size){
		return appServices.findCertifCandidats("%"+motCle+"%", page, size);
	}
	
	@RequestMapping(value = "/connexion", method=RequestMethod.POST)
	public Candidat connexion(@RequestBody Candidat candidat  ){
		Candidat user = new Candidat();
		user = appServices.candidatByEmail(candidat.getEmail());
		
		user = appServices.candidatByEmail(candidat.getEmail());
		if(user!=null){
			user.setEtat(1);
			appServices.updateCandidat(user);
		}else {
			user=candidat;
			user.setEtat(0);
		}
		
		return user;
	}
	@RequestMapping(value = "/deconnexion", method=RequestMethod.POST)
	public void deconnexion(@RequestBody Candidat candidat  ){
		Candidat user = new Candidat();
		user= appServices.candidatByEmail(candidat.getEmail());;
		user.setEtat(0);
		appServices.updateCandidat(user);
	}
	@RequestMapping(value = "/offres", method=RequestMethod.POST)
	public void saveOffre(@RequestBody AppUser offre  ){
		
		appServices.saveUser(offre);
	}
}
