//package com.paquage.web;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.paquage.services.AppServices;
//
//public class RegisterForm {
//	private String email;
//	private String password;
//	private String repassword;
//	private int etat;
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
//	public String getPassword() {
//		return password;
//	}
//	public void setPassword(String password) {
//		this.password = password;
//	}
//	public String getRepassword() {
//		return repassword;
//	}
//	public void setRepassword(String repassword) {
//		this.repassword = repassword;
//	}
//	public int getEtat() {
//		return etat;
//	}
//	public void setEtat(int etat) {
//		this.etat = etat;
//	}
//	
//	
//	
//}
