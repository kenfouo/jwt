package com.paquage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Bean;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.paquage.dao.AppRoleRepository;
import com.paquage.dao.AppUserRepository;
import com.paquage.dao.CandidatRepository;
import com.paquage.dao.CertificationCandidatRepository;
import com.paquage.dao.CertificationRepository;
import com.paquage.dao.DomaineRepository;
import com.paquage.dao.ExperienceRepository;
import com.paquage.dao.FormationRepository;
import com.paquage.dao.LangueRepository;
import com.paquage.dao.TechnologieRepository;
import com.paquage.entities.AppRole;
import com.paquage.entities.AppUser;
import com.paquage.entities.Candidat;
import com.paquage.entities.Certification;
import com.paquage.entities.CertificationCandidat;
import com.paquage.entities.Contrat;
import com.paquage.entities.Domaine;
import com.paquage.entities.Experience;
import com.paquage.entities.Formation;
import com.paquage.entities.Langue;
import com.paquage.entities.Niveau;
import com.paquage.entities.Technologie;
import com.paquage.services.AppServices;



@SpringBootApplication
public class CvThequeBackEndApplication implements CommandLineRunner{
	@Autowired
	private AppRoleRepository appRoleRepository;
	
	@Autowired
	private AppUserRepository appUserRepository;
	
	@Autowired
	private DomaineRepository domaineRepository;
	
	@Autowired
	private TechnologieRepository technologieRepository;
	
	@Autowired
	private CertificationRepository certificationRepository;
	
	@Autowired
	private LangueRepository langueRepository;;
	
	@Autowired
	private CandidatRepository candidatRepository;
	
	@Autowired
	private ExperienceRepository experienceRepository;
	
	
	@Autowired
	private CertificationCandidatRepository certificationCandidatRepository;
	@Autowired
	private  AppServices appServices;
	@Autowired
	private FormationRepository formationRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(CvThequeBackEndApplication.class, args);
		
	}

//	@Override
//	public void run(String... args) throws Exception {
//		appServices.saveUser(new AppUser("admin","1234",null));
//		appServices.saveUser(new AppUser("user","1234",null));
//		appServices.saveRole(new AppRole("ADMIN"));
//		appServices.saveRole(new AppRole("USER"));
//		appServices.addRoleToUse("admin", "ADMIN");
//		appServices.addRoleToUse("admin", "USER");
//	}
	
//	@Bean
//	public BCryptPasswordEncoder getBCPE() {
//		return new BCryptPasswordEncoder();
//	}
	

	
	@Override
	public void run(String... args) throws Exception {
//		appRoleRepository.save(new AppRole("USER"));
//		appRoleRepository.save(new AppRole("ADMIN"));
//		appRoleRepository.save(new AppRole("SUPER_ADMIN"));
//		appRoleRepository.save(new AppRole("PETIT_USER"));
//		
//		appUserRepository.save(new AppUser("fffff","USER",null,1));
//		appUserRepository.save(new AppUser("ffffff","USER",null,1));
//		appUserRepository.save(new AppUser("borientm@yahoo.fr","ADMIN",null,1));
//		appUserRepository.save(new AppUser("fabrice@yahoo.fr","USER",null,1));
//		appUserRepository.save(new AppUser("romual@gmail.com","USER",null,1));
//		appUserRepository.save(new AppUser("cedricm@yahoo.fr","ADMIN",null,1));
//		appUserRepository.save(new AppUser("anicet@gmail.com","USER",null,1));
//		appUserRepository.save(new AppUser("guenkam@yahoo.fr","USER",null,1));
//		appUserRepository.save(new AppUser("beverly@gmail.com","USER",null,1));
//		appUserRepository.save(new AppUser("kom@yahoo.fr","ADMIN",null,1));
//		appUserRepository.save(new AppUser("kamgang@gmail.com","USER",null,1));
//		appUserRepository.save(new AppUser("cerena@yahoo.fr","ADMIN",null,1));
//		appUserRepository.save(new AppUser("ladouce@gmail.com","USER",null,1));
//		appUserRepository.save(new AppUser("kamto@yahoo.fr","USER",null,1));
//		appUserRepository.save(new AppUser("taguia@gmail.com","USER",null,1));
//		appUserRepository.save(new AppUser("julie@yahoo.fr","ADMIN",null,1));
//		appUserRepository.save(new AppUser("kounch@gmail.com","USER",null,1));
//		
//		
//		
//		Domaine d2 = domaineRepository.save(new Domaine("INFORMATIQUE ET RESEAUX"));
//		Domaine d3 = domaineRepository.save(new Domaine("RESEAUX ET TELECOM"));
//		Domaine d4 = domaineRepository.save(new Domaine("AGRONOMIE"));
//		Domaine d5 = domaineRepository.save(new Domaine("MECANIQUE"));
//		Domaine d6 = domaineRepository.save(new Domaine("PHARMACIE"));
//		Domaine d7 = domaineRepository.save(new Domaine("MEDECINE"));
//		Domaine d8 = domaineRepository.save(new Domaine("BIOLOGIE"));
//		Domaine d9 = domaineRepository.save(new Domaine("ASTRONOMIE"));
//		Domaine d10 = domaineRepository.save(new Domaine("LOGISTIQUE"));
//		domaineRepository.save(new Domaine("TRANSPORT"));
//		Domaine d1 = domaineRepository.save(new Domaine("CHIMIE"));
//		Domaine d12 = domaineRepository.save(new Domaine("PHYSIQUE"));
//		Domaine d13 = domaineRepository.save(new Domaine("DIETETIQUE"));
//		Domaine d14 = domaineRepository.save(new Domaine("COMMERCE"));
//		Domaine d15 = domaineRepository.save(new Domaine("MARKETING"));
//		Domaine d17 = domaineRepository.save(new Domaine("COMPTABILITE"));
//		Domaine d18 = domaineRepository.save(new Domaine("BANQUE"));
//		
//		
//		technologieRepository.save(new Technologie("HTML"));
//		technologieRepository.save(new Technologie("XML"));
//		technologieRepository.save(new Technologie("AJAX"));
//		technologieRepository.save(new Technologie("JAVA"));
//		technologieRepository.save(new Technologie("CSS"));
//		technologieRepository.save(new Technologie("JavaScript"));
//		technologieRepository.save(new Technologie("JAVA"));
//		technologieRepository.save(new Technologie("C"));
//		technologieRepository.save(new Technologie("C++"));
//		technologieRepository.save(new Technologie("C#"));
//		technologieRepository.save(new Technologie("BOOTSTRAP"));
//		technologieRepository.save(new Technologie("VISUAL BASIC"));
//		technologieRepository.save(new Technologie("PYTHON"));
//		
//		
//		Certification cc1= certificationRepository.save(new Certification("CISCO-CCNA",d1 ));
//		Certification cc2= certificationRepository.save(new Certification("ORACLE DATABASE",d1 ));
//		Certification cc3= certificationRepository.save(new Certification("MySQL",d1 ));
//		Certification cc4= certificationRepository.save(new Certification("Word-Excel",d1 ));
//		certificationRepository.save(new Certification("Php",d1 ));
//		certificationRepository.save(new Certification("Java",d1 ));
//		certificationRepository.save(new Certification("AFNOR",d1 ));
//		
//	
//		DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
//		
//		Candidat c1 = candidatRepository.save(new Candidat("MANFOUO KENFOUO" ,"Borient", df.parse("2018/02/17"),"borient@gmail.com","1234", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c2 = candidatRepository.save(new Candidat("MELACHIO" ,"Bernard", df.parse("2012/02/17"), "","", "MAROUA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user"));
//		Candidat c3 = candidatRepository.save(new Candidat("AKONO" ,"Jule", df.parse("2016/02/17"), "","", "YAOUNDE", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","admin" ));
//		Candidat c4 = candidatRepository.save(new Candidat("KONLACK" ,"Christ", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","admin" ));
//		Candidat c5 = candidatRepository.save(new Candidat("ISSA" ,"ARMET", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré" ,"user"));
//		Candidat c6 = candidatRepository.save(new Candidat("Yousouf kadidja" ,"amine", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","admin" ));
//		Candidat c7 = candidatRepository.save(new Candidat("armet hetel" ,"zaed", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","admin" ));
//		Candidat c8 = candidatRepository.save(new Candidat("Moussa" ,"Kamara", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","admin" ));
//		Candidat c9 = candidatRepository.save(new Candidat("karim" ,"ismael", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		
//		Candidat c10 = candidatRepository.save(new Candidat("ngouo" ,"judith", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 1, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c11 = candidatRepository.save(new Candidat("MANFOUO KENFOUO" ,"Borient", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c12 = candidatRepository.save(new Candidat("MELACHIO" ,"Bernard", df.parse("2012/02/17"), "","", "MAROUA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c13 = candidatRepository.save(new Candidat("AKONO" ,"Jule", df.parse("2016/02/17"), "","", "YAOUNDE", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c14 = candidatRepository.save(new Candidat("KONLACK" ,"Christ", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c15 = candidatRepository.save(new Candidat("ISSA" ,"ARMET", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c16 = candidatRepository.save(new Candidat("Yousouf kadidja" ,"amine", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c17 = candidatRepository.save(new Candidat("armet hetel" ,"zaed", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c18 = candidatRepository.save(new Candidat("Moussa" ,"Kamara", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c19 = candidatRepository.save(new Candidat("karim" ,"ismael", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		Candidat c20 = candidatRepository.save(new Candidat("ngouo" ,"judith", df.parse("2018/02/17"), "","", "MBOUDA", "Homme", "Dschang", "Cameroun", "Cameroun", "655393119", "Celibataire", 2, 0, "/photo", "je suis à la recherche d'un emploi stable et bien rémunéré","user" ));
//		//Collection<Candidat> candid = null; candid.add(c1);
//		
//		certificationCandidatRepository.save(new CertificationCandidat(df.parse("2018/02/03"),"/pjointe", c1, cc2));
//		certificationCandidatRepository.save(new CertificationCandidat(df.parse("2018/02/03"),"/pjointe", c2, cc2));
//		certificationCandidatRepository.save(new CertificationCandidat(df.parse("2018/02/03"),"/pjointe", c1, cc1));
//		
//		
//		langueRepository.save(new Langue(Niveau.ELEVE, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT,c1));
//		langueRepository.save(new Langue(Niveau.ELEVE, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT,c2));
//		langueRepository.save(new Langue(Niveau.ELEVE, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, c3));
//		langueRepository.save(new Langue(Niveau.ELEVE, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT, Niveau.DEBUTANT,c4));
//		
//		experienceRepository.save(new Experience(df.parse("2012/02/17"), df.parse("2012/02/17"), "Societé des Provenderie du cameroun", "Chef Cellule Anformatique", Contrat.CDI, "gestionnaire des BD ","/pjointe","Cameroun","Yaounde", c1, d2));
//		experienceRepository.save(new Experience(df.parse("2012/02/17"), df.parse("2002/02/17"), "Afrilad Banck", "Assistant Chef Cellule Anformatique", Contrat.INTERIM, "maintenance réseau et logiciel ","/pjointe","Senegal","Dakar", c1, d1));
//		experienceRepository.save(new Experience(df.parse("2012/02/17"), df.parse("2010/02/17"), "SPC", "Directreur des Réssources Humaine", Contrat.STAGEACCADEDIQUE, "gestion du personnel ","/pjointe","Benin","Kotonour", c1, d3));
//		experienceRepository.save(new Experience(df.parse("2012/02/17"), df.parse("2019/02/17"), "Societé des Provenderie du cameroun", "Prefet de discipline", Contrat.INTERIM, "veil au respect des principes de l'entreprise ","/pjointe","Guinée Equatoriale","Malabo", c1, d4));
//		experienceRepository.save(new Experience(df.parse("2012/02/17"), df.parse("2011/02/17"), "Camlait", "Directeur d'administration", Contrat.CDI, "coordonation des sactivités du personnel","/pjointe","Cameroun","Mbouda", c1, d5));
//		experienceRepository.save(new Experience(df.parse("2012/02/17"), df.parse("2013/02/17"), "CHOCOCAM", "agent comptable", Contrat.TEMPSPARTIEL, "passation des écriture ","/pjointe","Cameroun","Douala", c1, d6));
//		
//		
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Dschang", "TIC", "la formation vise à maitriser l'outil informatique","Dschang", "Cameroun","PROBATOIRE TI","/photo/bac", c1));
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Bafoussam", "TIC", "la formation vise à maitriser l'outil informatique","Douala", "Cameroun","BACCALAUREAT TI","/photo/bac", c1));
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Dschang", "TIC", "la formation vise à maitriser l'outil informatique","Mbouda", "Cameroun","BREVET DES TECHNICIENS SUPERIEURS","/photo/bac", c1));
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Dschang", "TIC", "la formation vise à maitriser l'outil informatique","Yaoundé", "Cameroun","LICENCE PRO","/photo/bac", c1));
//		
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Dschang", "TIC", "la formation vise à maitriser l'outil informatique","Dschang", "Cameroun","PROBATOIRE TI","/photo/bac", c2));
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Bafoussam", "TIC", "la formation vise à maitriser l'outil informatique","Douala", "Cameroun","BACCALAUREAT TI","/photo/bac", c3));
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Dschang", "TIC", "la formation vise à maitriser l'outil informatique","Mbouda", "Cameroun","BREVET DES TECHNICIENS SUPERIEURS","/photo/bac", c4));
//		formationRepository.save(new Formation(df.parse("2018/03/05"), df.parse("2011/03/05"), "Lycée Bilingue de Dschang", "TIC", "la formation vise à maitriser l'outil informatique","Yaoundé", "Cameroun","LICENCE PRO","/photo/bac", c5));
//		
//		candidatRepository.findAll().forEach(
//				c->{System.out.println(c.getDateNaiss());}
//				);
		
	}

}
