package com.paquage.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.paquage.entities.Experience;

public interface ExperienceRepository extends JpaRepository<Experience, Long>{
	@Query("select experience from Experience experience where experience.ville like :x")
	public Page<Experience> findExperiences(@Param("x") String motCle, Pageable page);
}
