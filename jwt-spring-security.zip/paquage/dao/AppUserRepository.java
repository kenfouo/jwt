package com.paquage.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.paquage.entities.AppUser;

public interface AppUserRepository extends JpaRepository<AppUser, Long>{
	public AppUser findByemail(String email);
}
