package com.paquage.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.paquage.entities.Formation;

public interface FormationRepository extends JpaRepository<Formation, Long>{
	@Query("select formation from Formation formation where formation.intitule like :x")
	public Page<Formation> findFormations(@Param("x") String motCle, Pageable page);
}
