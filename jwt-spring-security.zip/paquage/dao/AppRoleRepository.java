package com.paquage.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paquage.entities.AppRole;

public interface AppRoleRepository extends JpaRepository<AppRole, Long>{
	public AppRole findByRole(String role);
}
