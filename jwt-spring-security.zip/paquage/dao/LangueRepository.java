package com.paquage.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paquage.entities.Langue;

public interface LangueRepository extends JpaRepository<Langue, Long> {

}
