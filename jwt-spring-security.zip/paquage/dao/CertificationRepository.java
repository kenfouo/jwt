package com.paquage.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.paquage.entities.Certification;

public interface CertificationRepository extends JpaRepository<Certification, Long>{
	@Query("select certification from Certification certification where certification.libelle like :x")
	public Page<Certification> findCertifications(@Param("x") String motCle, Pageable page);
}
