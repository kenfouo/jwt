
package com.paquage.dao;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.paquage.entities.CertificationCandidat;

public interface CertificationCandidatRepository extends JpaRepository<CertificationCandidat, Long> {
	@Query("select certifCandidat from CertificationCandidat certifCandidat where certifCandidat.dateObtention like :x")
	public Page<CertificationCandidat> findCertifcandidats(@Param("x") String motCle, Pageable page);
}
