package com.paquage.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Langue {

	@Id @GeneratedValue
	private Long id;
	private Niveau frParle;
	private Niveau frEcrit;
	private Niveau frLu;
	private Niveau enParle;
	private Niveau enEcrit;
	private Niveau enLu;
	
	
	@OneToOne
	@JsonIgnore
	private Candidat candidat;
	
	public Langue() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Langue(Niveau frParle, Niveau frEcrit, Niveau frLu, Niveau enParle, Niveau enEcrit, Niveau enLu,
			Candidat candidat) {
		super();
		this.frParle = frParle;
		this.frEcrit = frEcrit;
		this.frLu = frLu;
		this.enParle = enParle;
		this.enEcrit = enEcrit;
		this.enLu = enLu;
		this.candidat = candidat;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Niveau getFrParle() {
		return frParle;
	}
	public void setFrParle(Niveau frParle) {
		this.frParle = frParle;
	}
	public Niveau getFrEcrit() {
		return frEcrit;
	}
	public void setFrEcrit(Niveau frEcrit) {
		this.frEcrit = frEcrit;
	}
	public Niveau getFrLu() {
		return frLu;
	}
	public void setFrLu(Niveau frLu) {
		this.frLu = frLu;
	}
	public Niveau getEnParle() {
		return enParle;
	}
	public void setEnParle(Niveau enParle) {
		this.enParle = enParle;
	}
	public Niveau getEnEcrit() {
		return enEcrit;
	}
	public void setEnEcrit(Niveau enEcrit) {
		this.enEcrit = enEcrit;
	}
	public Niveau getEnLu() {
		return enLu;
	}
	public void setEnLu(Niveau enLu) {
		this.enLu = enLu;
	}
	public Candidat getCandidat() {
		return candidat;
	}
	public void setCandidat(Candidat candidat) {
		this.candidat = candidat;
	}

	
	
}
