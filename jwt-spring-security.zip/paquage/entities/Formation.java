package com.paquage.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
public class Formation implements Serializable {
	@Id @GeneratedValue
	private Long id;
	private Date dateDebut;
	private Date dateFin;
	private String etablissement;
	private String intitule;
	private String description;
	private String ville;
	private String pays;
	private String diplome;
	private String pieceJointe;
	

	@JsonIgnore
	@ManyToOne
//	@JoinColumn(name = "CODE_CANDIDAT")
	private Candidat candidat;


	public Formation() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Formation(Date dateDebut, Date dateFin, String etablissement, String intitule, String description,
			String ville, String pays, String diplome, String pieceJointe, Candidat candidat) {
		super();
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
		this.etablissement = etablissement;
		this.intitule = intitule;
		this.description = description;
		this.ville = ville;
		this.pays = pays;
		this.diplome = diplome;
		this.pieceJointe = pieceJointe;
		this.candidat = candidat;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Date getDateDebut() {
		return dateDebut;
	}


	public void setDateDebut(Date dateDebut) {
		this.dateDebut = dateDebut;
	}


	public Date getDateFin() {
		return dateFin;
	}


	public void setDateFin(Date dateFin) {
		this.dateFin = dateFin;
	}


	public String getEtablissement() {
		return etablissement;
	}


	public void setEtablissement(String etablissement) {
		this.etablissement = etablissement;
	}


	public String getIntitule() {
		return intitule;
	}


	public void setIntitule(String intitule) {
		this.intitule = intitule;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getVille() {
		return ville;
	}


	public void setVille(String ville) {
		this.ville = ville;
	}


	public String getPays() {
		return pays;
	}


	public void setPays(String pays) {
		this.pays = pays;
	}


	public String getDiplome() {
		return diplome;
	}


	public void setDiplome(String diplome) {
		this.diplome = diplome;
	}


	public String getPieceJointe() {
		return pieceJointe;
	}


	public void setPieceJointe(String pieceJointe) {
		this.pieceJointe = pieceJointe;
	}


	public Candidat getCandidat() {
		return candidat;
	}


	public void setCandidat(Candidat candidat) {
		this.candidat = candidat;
	}

	
	
}
