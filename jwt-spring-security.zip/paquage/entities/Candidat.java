package com.paquage.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
public class Candidat implements Serializable {
	@Id @GeneratedValue
	private Long id;
	private String nom;
	private String prenom;
	@Temporal(TemporalType.DATE)
	private Date dateNaiss;
	private String email;
	private String password;
	private String lieuNaiss;
	private String sexe;
	private String ville;
	private String paysOrigine;
	private String paysNaiss;
	private String tel;
	private String statut;
	private int nbEnfant;
	private int etat;
	private String photo;
	private String resume;
	private String role;
	

	@OneToMany(mappedBy = "candidat")
	private Collection<CertificationCandidat> certificationCandidats;
	
	@OneToMany (mappedBy="candidat",fetch=FetchType.LAZY)
	private Collection<Formation> formations;
	
	@OneToMany(mappedBy="candidat",fetch=FetchType.LAZY)
	private Collection<Loisir> loisirs;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable
	private Set<Technologie> technologies;
	
	@ManyToMany(mappedBy = "candidats")
	private Collection<Domaine> domaines;

	@OneToMany (mappedBy="candidat",fetch=FetchType.LAZY)
	private Collection<Experience> experiences;
	
	@OneToMany(mappedBy="candidat",fetch=FetchType.LAZY)
	private Collection<Langue> langues;

	public Candidat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Candidat(String nom, String prenom, Date dateNaiss, String email, String password, String lieuNaiss,
			String sexe, String ville, String paysOrigine, String paysNaiss, String tel, String statut, int nbEnfant, int etat,
			String photo, String resume,String role) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaiss = dateNaiss;
		this.email = email;
		this.password = password;
		this.lieuNaiss = lieuNaiss;
		this.sexe = sexe;
		this.ville = ville;
		this.paysOrigine = paysOrigine;
		this.paysNaiss = paysNaiss;
		this.tel = tel;
		this.statut = statut;
		this.nbEnfant = nbEnfant;
		this.etat =etat;
		this.photo = photo;
		this.resume = resume;
		this.role = role;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Date getDateNaiss() {
		return dateNaiss;
	}

	public void setDateNaiss(Date dateNaiss) {
		this.dateNaiss = dateNaiss;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLieuNaiss() {
		return lieuNaiss;
	}

	public void setLieuNaiss(String lieuNaiss) {
		this.lieuNaiss = lieuNaiss;
	}

	public String getSexe() {
		return sexe;
	}

	public void setSexe(String sexe) {
		this.sexe = sexe;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getPaysOrigine() {
		return paysOrigine;
	}

	public void setPaysOrigine(String paysOrigine) {
		this.paysOrigine = paysOrigine;
	}

	public String getPaysNaiss() {
		return paysNaiss;
	}

	public void setPaysNaiss(String paysNaiss) {
		this.paysNaiss = paysNaiss;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	public int getNbEnfant() {
		return nbEnfant;
	}

	public void setNbEnfant(int nbEnfant) {
		this.nbEnfant = nbEnfant;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public Collection<CertificationCandidat> getCertificationCandidats() {
		return certificationCandidats;
	}

	public void setCertificationCandidats(Collection<CertificationCandidat> certificationCandidats) {
		this.certificationCandidats = certificationCandidats;
	}

	public Collection<Formation> getFormations() {
		return formations;
	}

	public void setFormations(Collection<Formation> formations) {
		this.formations = formations;
	}

	public Collection<Loisir> getLoisirs() {
		return loisirs;
	}

	public void setLoisirs(Collection<Loisir> loisirs) {
		this.loisirs = loisirs;
	}

	public Set<Technologie> getTechnologies() {
		return technologies;
	}

	public void setTechnologies(Set<Technologie> technologies) {
		this.technologies = technologies;
	}

	public Collection<Domaine> getDomaines() {
		return domaines;
	}

	public void setDomaines(Collection<Domaine> domaines) {
		this.domaines = domaines;
	}

	public Collection<Experience> getExperiences() {
		return experiences;
	}

	public void setExperiences(Collection<Experience> experiences) {
		this.experiences = experiences;
	}

	public Collection<Langue> getLangues() {
		return langues;
	}

	public void setLangues(Collection<Langue> langues) {
		this.langues = langues;
	}
	public int getEtat() {
		return etat;
	}

	public void setEtat(int etat) {
		this.etat = etat;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	
//file upload


}
