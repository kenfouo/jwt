package com.paquage.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Certification implements Serializable{
	@Id @GeneratedValue
	private Long id;
	private String libelle;
	
	@OneToOne
	private Domaine domaine;
		
	@OneToMany (mappedBy = "certification")
	private Collection<CertificationCandidat> certificationCandidats;

	public Certification() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Certification(String libelle, Domaine domaine) {
		super();
		this.libelle = libelle;
		
		this.domaine = domaine;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public Domaine getDomaine() {
		return domaine;
	}

	public void setDomaine(Domaine domaine) {
		this.domaine = domaine;
	}

	public Collection<CertificationCandidat> getCertificationCandidats() {
		return certificationCandidats;
	}

	public void setCertificationCandidats(Collection<CertificationCandidat> certificationCandidats) {
		this.certificationCandidats = certificationCandidats;
	}

}
