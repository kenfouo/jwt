package com.paquage.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Loisir implements Serializable{
	@Id @GeneratedValue
	private Long id;
	
	private String libelle;
	
	@ManyToOne
	@JsonIgnore
	private Candidat candidat;
	
	public Loisir() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Loisir(String libelle, Candidat candidat) {
		super();
		this.libelle = libelle;
		this.candidat = candidat;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public Candidat getCandidat() {
		return candidat;
	}

	public void setCandidat(Candidat candidat) {
		this.candidat = candidat;
	}
	

}
