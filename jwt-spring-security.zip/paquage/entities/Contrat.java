package com.paquage.entities;

public enum Contrat {

	CDI,
	CDD,
	STAGEACCADEDIQUE,
	STAGEPREEMPLOI,
	INTERIM,
	TEMPSPARTIEL
	
}
