package com.paquage.entities;

public enum Niveau {

	DEBUTANT,
	MOYEN,
	ELEVE,
	EXCELLENT
}
