package com.paquage.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.core.sym.Name;

@Entity
public class Reference implements Serializable {
	@Id @GeneratedValue
	private Long id;
	private String libelle;
	private String url;
	@ManyToOne
	@JoinColumn(name = "CODE_EXPERIANCE")
	private Experience experience;
	public Reference() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reference(String libelle, String url, Experience experience) {
		super();
		this.libelle = libelle;
		this.url = url;
		this.experience = experience;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Experience getExperience() {
		return experience;
	}
	public void setExperience(Experience experience) {
		this.experience = experience;
	}
	
	
	

	
}
