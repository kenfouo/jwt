package com.paquage.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class CertificationCandidat implements Serializable{
	@Id @GeneratedValue
	private Long id;
	
	private Date dateObtention;
	private String pieceJointe;
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "CODE_CANDIDAT")
	private Candidat candidat;
	@JsonIgnore
	@ManyToOne
	//@JoinColumn(name = "CODE_CERTIFICATION")
	private Certification certification;

	public CertificationCandidat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CertificationCandidat(Date dateObtention, String pieceJointe, Candidat candidat,
			Certification certification) {
		super();
		this.dateObtention = dateObtention;
		this.pieceJointe = pieceJointe;
		this.candidat = candidat;
		this.certification = certification;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDateObtention() {
		return dateObtention;
	}

	public void setDateObtention(Date dateObtention) {
		this.dateObtention = dateObtention;
	}

	public String getPieceJointe() {
		return pieceJointe;
	}

	public void setPieceJointe(String pieceJointe) {
		this.pieceJointe = pieceJointe;
	}

	public Candidat getCandidat() {
		return candidat;
	}

	public void setCandidat(Candidat candidat) {
		this.candidat = candidat;
	}

	public Certification getCertification() {
		return certification;
	}

	public void setCertification(Certification certification) {
		this.certification = certification;
	}

	

	
	
}
