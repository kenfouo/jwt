package com.paquage.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;



@Entity
public class AppUser implements Serializable{
    @Id
    @GeneratedValue
    private Long id;
    private String email;
    private String password;
    private int etat;

    
    
    @ManyToMany(fetch=FetchType.EAGER)
    private Collection<AppRole> roles = new ArrayList<>();



	public AppUser() {
		super();
		// TODO Auto-generated constructor stub
	}



	public AppUser(String email, String password, Collection<AppRole> roles, int etat) {
		super();
		this.email = email;
		this.password = password;
		this.roles = roles;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}


	@JsonIgnore
	public String getPassword() {
		return password;
	}


	@JsonSetter
	public void setPassword(String password) {
		this.password = password;
	}

	public Collection<AppRole> getRoles() {
		return roles;
	}



	public void setRoles(Collection<AppRole> roles) {
		this.roles = roles;
	}


}

