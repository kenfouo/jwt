package com.paquage.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Domaine implements Serializable{
	@Id @GeneratedValue
	private Long id;
	private String domaine;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	@JoinTable
	private Collection<Candidat>candidats;

	public Domaine() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Domaine(String domaine) {
		super();
		this.domaine = domaine;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDomaine() {
		return domaine;
	}

	public void setDomaine(String domaine) {
		this.domaine = domaine;
	}

	public Collection<Candidat> getCandidats() {
		return candidats;
	}

	public void setCandidats(Collection<Candidat> candidats) {
		this.candidats = candidats;
	}
	

	
	
}
