package com.paquage.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Experience implements Serializable {
	@Id @GeneratedValue
	private Long id;
	private Date dateDebut;
	private Date dateFin;
	private String entreprise;
	private String posteOccupe;
	private Contrat contrat = Contrat.CDI;
	private String missionsOuTches ;
	private String pieceJointe;
	private String pays;
	private String ville;
	
	@ManyToMany(mappedBy = "experiences")
	private Set<Technologie> technologies;
	
	@OneToMany(mappedBy="experience", fetch=FetchType.LAZY)
	private Collection<Reference> references;
	
	@ManyToOne
	@JsonIgnore
	private Candidat candidat;
	
	@ManyToOne
	private Domaine domaine;

	public Experience() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Experience(Date dateDebut, Date dateFin, String entreprise, String posteOccupe, Contrat contrat,
			String missionsOuTches, String pieceJointe, String pays, String ville, Candidat candidat, Domaine domaine) {
		super();
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
		this.entreprise = entreprise;
		this.posteOccupe = posteOccupe;
		this.contrat = contrat;
		this.missionsOuTches = missionsOuTches;
		this.pieceJointe = pieceJointe;
		this.pays = pays;
		this.ville = ville;
		this.candidat = candidat;
		this.domaine = domaine;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(Date dateDebut) {
		this.dateDebut = dateDebut;
	}

	public Date getDateFin() {
		return dateFin;
	}

	public void setDateFin(Date dateFin) {
		this.dateFin = dateFin;
	}

	public String getEntreprise() {
		return entreprise;
	}

	public void setEntreprise(String entreprise) {
		this.entreprise = entreprise;
	}

	public String getPosteOccupe() {
		return posteOccupe;
	}

	public void setPosteOccupe(String posteOccupe) {
		this.posteOccupe = posteOccupe;
	}

	public Contrat getContrat() {
		return contrat;
	}

	public void setContrat(Contrat contrat) {
		this.contrat = contrat;
	}

	public String getMissionsOuTches() {
		return missionsOuTches;
	}

	public void setMissionsOuTches(String missionsOuTches) {
		this.missionsOuTches = missionsOuTches;
	}

	public String getPieceJointe() {
		return pieceJointe;
	}

	public void setPieceJointe(String pieceJointe) {
		this.pieceJointe = pieceJointe;
	}

	public String getPays() {
		return pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public Set<Technologie> getTechnologies() {
		return technologies;
	}

	public void setTechnologies(Set<Technologie> technologies) {
		this.technologies = technologies;
	}

	public Collection<Reference> getReferences() {
		return references;
	}

	public void setReferences(Collection<Reference> references) {
		this.references = references;
	}

	public Candidat getCandidat() {
		return candidat;
	}

	public void setCandidat(Candidat candidat) {
		this.candidat = candidat;
	}

	public Domaine getDomaine() {
		return domaine;
	}

	public void setDomaine(Domaine domaine) {
		this.domaine = domaine;
	}

	
}
