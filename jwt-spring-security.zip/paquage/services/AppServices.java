
package com.paquage.services;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Page;

import com.paquage.entities.AppRole;
import com.paquage.entities.AppUser;
import com.paquage.entities.Candidat;
import com.paquage.entities.Certification;
import com.paquage.entities.CertificationCandidat;
import com.paquage.entities.Domaine;
import com.paquage.entities.Experience;
import com.paquage.entities.Formation;

import com.paquage.entities.Reference;
import com.paquage.entities.Technologie;

public interface AppServices {
	

	public AppUser saveUser(AppUser appUser);
	public AppRole saveRole(AppRole role);
	public void addRoleToUse(String email, String role);
	public AppUser findUserByEmail(String email);
	public Collection<AppUser> findUserall();
	
	//CANDIDAT
	
	public Candidat findCandidat(Long id);
	public Page<Candidat> findCandidats(String motCle, int page, int size);
	public List<Candidat> allCandidats();	
	public Candidat saveCandidat(Candidat candidat);//String nom,String prenom,Date dateNaiss,String lieuDeNaissance,String sexe,String paysOrigine,String paysDeNaissance,int tel,String email,String statut,int nbEnfant,String photo,String resum
	public Candidat updateCandidat(Candidat candidat);
	public Candidat candidatByEmail(String email);
	public void deleteCandidat(Long id);
	
	//CERTIFICATIONS
	
	public Certification findCertification(Long id);
	public Page<Certification> findCertifications(String motCle, int page, int size);
	public List<Certification> allCertifications();	
	public Certification saveCertification(Certification certification);
	public Certification updateCertification(Certification certification);
	public void deleteCertification(Long id);	
		
	// DOMAINE DE COMPETENCE
		
	public Domaine findDomaine(Long id);
	public Page<Domaine> findDomaines(String motCle, int page, int size);
	public List<Domaine> allDomaines();	
	public Domaine saveDomaine(Domaine domaine);
	public Domaine updateDomaine(Domaine domaine);
	public void deleteDomaine(Long id);
	
	// EXPERIENCE
	
	public Experience findExperience(Long id);
	public Page<Experience> findExperiences(String motCle, int page, int size);
	public List<Experience> allExperiences();	
	public Experience saveExperience(Experience experience);
	public Experience updateExperience(Experience experience);
	public void deleteExperience(Long id);
	
	// FORMATIONS
	
	public Formation findFormation(Long id);
	public Page<Formation> findFormations(String motCle, int page, int size);
	public List<Formation> allFormations();	
	public Formation saveFormation(Formation formation);
	public Formation updateFormation(Formation formation);
	public void deleteFormation(Long id);
	
	// LOISIRS
	
/*	public Loisirs findLoisir(Long id);
	public Page<Loisirs> findLoisirs(String motCle, int page, int size);
	public List<Loisirs> allLoisirs();	
	public Loisirs saveLoisir(Loisirs loisir);
	public Loisirs updateLoisir(Loisirs loisir);
	public void deleteLoisir(Long id);*/
	
	// REFERENCE EXPERIENCE
	
	public Reference findReference(Long id);
	public Page<Reference> findReferences(String motCle, int page, int size);
	public List<Reference> allReferences();	
	public Reference saveReference(Reference reference);
	public Reference updateReference(Reference reference);
	public void deleteReference(Long id);
	
	// TECHNOLOGIES MAITRISEES
	
	public Technologie findTechnologie(Long id);
	public Page<Technologie> findTechnologies(String motCle, int page, int size);
	public List<Technologie> allTechnologies();	
	public Technologie saveTechnologie(Technologie technologieMaitrisee);
	public Technologie updateTechnologie(Technologie technologieMaitrisee);
	public void deleteTechnologie(Long id);
	
	// CERTIFICATION CANDIDAT
	
	//public CertificationCandidat findCertifCandidat(Long id);
	public Page<Certification> findCertifCandidats(String motCle, int page, int size);
	public List<CertificationCandidat> allCertifCandidats();	
	public CertificationCandidat saveCertifCandidat(CertificationCandidat certificationCandidatt);
	public CertificationCandidat updateCertifCandidat(CertificationCandidat certificationCandidat);
	public void deleteCertifCandidat(Long id);
	
	
	
}
