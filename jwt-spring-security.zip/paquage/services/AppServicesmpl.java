package com.paquage.services;


import java.util.Collection;

//import static org.assertj.core.api.Assertions.useRepresentation;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.paquage.dao.AppRoleRepository;
import com.paquage.dao.AppUserRepository;
import com.paquage.dao.CandidatRepository;
import com.paquage.dao.CertificationCandidatRepository;
import com.paquage.dao.CertificationRepository;
import com.paquage.dao.DomaineRepository;
import com.paquage.dao.ExperienceRepository;
import com.paquage.dao.FormationRepository;
import com.paquage.dao.ReferenceRepository;
import com.paquage.dao.TechnologieRepository;
import com.paquage.entities.AppRole;
import com.paquage.entities.AppUser;
import com.paquage.entities.Candidat;
import com.paquage.entities.Certification;
import com.paquage.entities.CertificationCandidat;
import com.paquage.entities.Domaine;
import com.paquage.entities.Experience;
import com.paquage.entities.Formation;
import com.paquage.entities.Reference;
import com.paquage.entities.Technologie;


@Service
@Transactional
public class AppServicesmpl implements AppServices{
	
//	@Autowired
//	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private AppRoleRepository appRoleRepository;
	@Autowired
	private AppUserRepository appUserRepository;
	@Autowired
	private CandidatRepository candidatRepository;
	@Autowired
	private CertificationRepository certificationRepository;
	@Autowired
	private DomaineRepository domaineRepository;
	@Autowired
	private ExperienceRepository experienceRepository;
	@Autowired
	private FormationRepository formationRepository;
	@Autowired
	private ReferenceRepository referenceRepository;
	@Autowired
	private TechnologieRepository technologieRepository;
	@Autowired
	private CertificationCandidatRepository certificationCandidatRepository;
	
	
	// ROLE && USER**************************************************************************************************************

	@Override
	public AppUser saveUser(AppUser appUser) {
//		String hashPW = bCryptPasswordEncoder.encode(appUser.getPassword());
//		appUser.setPassword(hashPW);
		return appUserRepository.save(appUser);
	}
	@Override
	public AppRole saveRole(AppRole role) {
		return appRoleRepository.save(role);
	}
	
	@Override
	public void addRoleToUse(String email, String role) {
		AppRole appRole=appRoleRepository.findByRole(role);
		AppUser user=appUserRepository.findByemail(email);
		user.getRoles().add(appRole);
	}
	@Override
	public AppUser findUserByEmail(String email) {
		
		return appUserRepository.findByemail(email);
	}
	@Override
	public Collection<AppUser> findUserall() {
		// TODO Auto-generated method stub
		return null;
	}
	
	// CANDIDAT**********************************************************************************************************
	
	@Override
	public Candidat findCandidat(Long id) {
		return candidatRepository.findOne(id);
	}

	@Override
	public Page<Candidat> findCandidats(String motCle, int page, int size) {
		return candidatRepository.findCandidats(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Candidat> allCandidats() {
		return candidatRepository.findAll();
	}
	
	@Override
	public Candidat saveCandidat(Candidat candidat) {
		//String nom,String prenom,Date dateNaiss,String lieuDeNaissance,String sexe,String paysOrigine,String paysDeNaissance,int tel,String email,String statut,int nbEnfant,String photo,String resume
		return candidatRepository.save(candidat);
	}

	@Override
	public Candidat updateCandidat(Candidat candidat) {
		//nom, prenom, dateNaiss, lieuDeNaissance, sexe, paysOrigine, paysDeNaissance, tel, email, statut, nbEnfant, photo, resume
		return candidatRepository.saveAndFlush(candidat);
	}

	@Override
	public void deleteCandidat(Long id) {
		candidatRepository.delete(id);
		
	}
	@Override
	public Candidat candidatByEmail(String email) {
		
		return candidatRepository.findByemail(email);
	}
	
	
	
	//CERTIFICATIONS*****************************************************************************************************
	
	
	@Override
	public Certification findCertification(Long id) {
		return certificationRepository.findOne(id);
	}

	@Override
	public Page<Certification> findCertifications(String motCle, int page, int size) {
		return certificationRepository.findCertifications(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Certification> allCertifications() {
		return certificationRepository.findAll();
	}

	@Override
	public Certification saveCertification(Certification certification) {
		System.out.println(certification.getId());
		return certificationRepository.save(certification);
	}

	@Override
	public Certification updateCertification(Certification certification) {
		
		return certificationRepository.saveAndFlush(certification);
	}

	@Override
	public void deleteCertification(Long id) {
		certificationRepository.delete(id);
		
	}
	

	// DOMAINE DE COMPETANCE*********************************************************************************************
	
	
	@Override
	public Domaine findDomaine(Long id) {
		return domaineRepository.findOne(id);
	}

	@Override
	public Page<Domaine> findDomaines(String motCle, int page, int size) {
		return domaineRepository.findDomaines(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Domaine> allDomaines() {
		return domaineRepository.findAll();
	}

	@Override
	public Domaine saveDomaine(Domaine domaine) {
		return domaineRepository.save(domaine);
	}

	@Override
	public Domaine updateDomaine(Domaine domaine) {
		return domaineRepository.saveAndFlush(domaine);
	}

	@Override
	public void deleteDomaine(Long id) {
		domaineRepository.delete(id);
		
	}
	
	// EXPERIENCE********************************************************************************************************

	@Override
	public Experience findExperience(Long id) {
		return experienceRepository.findOne(id);
	}

	@Override
	public Page<Experience> findExperiences(String motCle, int page, int size) {
		return experienceRepository.findExperiences(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Experience> allExperiences() {
		return experienceRepository.findAll();
	}

	@Override
	public Experience saveExperience(Experience experience) {
		return experienceRepository.save(experience);
	}

	@Override
	public Experience updateExperience(Experience experience) {
		return experienceRepository.saveAndFlush(experience);
	}

	@Override
	public void deleteExperience(Long id) {
		experienceRepository.delete(id);		
	}

	
	// //FORMATIONS******************************************************************************************************
	
	
	@Override
	public Formation findFormation(Long id) {
		return formationRepository.findOne(id);
	}

	@Override
	public Page<Formation> findFormations(String motCle, int page, int size) {
		return formationRepository.findFormations(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Formation> allFormations() {
		return formationRepository.findAll();
	}

	@Override
	public Formation saveFormation(Formation formation) {
		return formationRepository.save(formation);
	}

	@Override
	public Formation updateFormation(Formation formation) {
		return formationRepository.saveAndFlush(formation);
	}

	@Override
	public void deleteFormation(Long id) {
		formationRepository.delete(id);
	}
	
	
	/*// LOISIRS***********************************************************************************************************
	
	@Override
	public Loisirs findLoisir(Long id) {
		return LoisirRepository.findOne(id);
	}

	@Override
	public Page<Loisirs> findLoisirs(String motCle, int page, int size) {
		return LoisirRepository.findLoisirs(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Loisirs> allLoisirs() {
		return LoisirRepository.findAll();
	}

	@Override
	public Loisirs saveLoisir(Loisirs loisir) {
		return LoisirRepository.save(loisir);
	}

	@Override
	public Loisirs updateLoisir(Loisirs loisir) {
		return LoisirRepository.saveAndFlush(loisir);
	}

	@Override
	public void deleteLoisir(Long id) {
		LoisirRepository.delete(id);
	}*/
	
	// REFERENCE EXPERIENCE**********************************************************************************************

	@Override
	public Reference findReference(Long id) {
		return referenceRepository.findOne(id);
	}

	@Override
	public Page<Reference> findReferences(String motCle, int page, int size) {
		return referenceRepository.findReferences(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Reference> allReferences() {
		return referenceRepository.findAll();
	}

	@Override
	public Reference saveReference(Reference reference) {
		return referenceRepository.save(reference);
	}

	@Override
	public Reference updateReference(Reference reference) {
		return referenceRepository.saveAndFlush(reference);
	}

	@Override
	public void deleteReference(Long id) {
		referenceRepository.delete(id);
	}

	// TECHNOLOGIES MAITRISEES*******************************************************************************************
	
	@Override
	public Technologie findTechnologie(Long id) {
		return technologieRepository.findOne(id);
	}

	@Override
	public Page<Technologie> findTechnologies(String motCle, int page, int size) {
		return technologieRepository.findTechnologies(motCle, new PageRequest(page, size));
	}

	@Override
	public List<Technologie> allTechnologies() {
		return technologieRepository.findAll();
	}

	@Override
	public Technologie saveTechnologie(Technologie technologieMaitrisee) {
		return technologieRepository.save(technologieMaitrisee);
	}

	@Override
	public Technologie updateTechnologie(Technologie technologieMaitrisee) {
		return technologieRepository.saveAndFlush(technologieMaitrisee);
	}

	@Override
	public void deleteTechnologie(Long id) {
		technologieRepository.delete(id);
	}
	
	
	// CERTIFICATION CANDIDAT ***********************************************************************************************
	
//		@Override
//		public CertificationCandidat findCertifCandidat(Long id) {
//			return certificationCandidatRepository.findOne(id);
//		}

		@Override
		public Page<Certification> findCertifCandidats(String motCle, int page, int size) {
			return certificationRepository.findCertifications(motCle, new PageRequest(page, size));
		}

		@Override
		public List<CertificationCandidat> allCertifCandidats() {
			return certificationCandidatRepository.findAll();
		}

		@Override
		public CertificationCandidat saveCertifCandidat(CertificationCandidat certifCandidat) {
			return certificationCandidatRepository.save(certifCandidat);
		}

		@Override
		public CertificationCandidat updateCertifCandidat(CertificationCandidat certifCandidat) {
			return certificationCandidatRepository.saveAndFlush(certifCandidat);
		}

		@Override
		public void deleteCertifCandidat(Long id) {
			certificationCandidatRepository.delete(id);
		}
		
}
